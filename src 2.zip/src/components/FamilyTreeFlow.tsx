import { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import {
  ReactFlow,
  Handle,
  Position,
  ReactFlowProvider,
  useReactFlow,
  useNodesInitialized,
  type Node,
  type Edge,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import './FamilyTreeFlow.css';

import familyData from '../data/family.json';

// ============================================
// TYPES
// ============================================
interface FamilyMember {
  id: string;
  name: string;
  spouse: string;
  children: FamilyMember[];
}

interface PersonNodeData {
  label: string;
  isExpandable: boolean;
  isExpanded: boolean;
  isSpouse: boolean;
  level: number;
  personId: string;
  [key: string]: unknown; // Index signature for React Flow compatibility
}

// ============================================
// CONSTANTS - Single source of truth for sizing
// ============================================
const LAYOUT = {
  NODE_WIDTH: 100,
  NODE_HEIGHT: 90,
  CIRCLE_SIZE: 60,
  HORIZONTAL_SPACING: 40,
  VERTICAL_SPACING: 140,
  SPOUSE_GAP: 90,
  CONNECTOR_DROP: 30,
  HORIZONTAL_BAR_DROP: 50,
} as const;

const LEVEL_COLORS: Record<number, string> = {
  1: '#343a40',
  2: '#495057',
  3: '#e74c3c',
  4: '#9b59b6',
  5: '#2980b9',
  6: '#27ae60',
  7: '#f39c12',
};

// ============================================
// CUSTOM PERSON NODE
// ============================================
function PersonNodeComponent({ data }: { data: PersonNodeData }) {
  const { label, isExpandable, isExpanded, isSpouse, level } = data;

  return (
    <div
      className={`person-node ${isExpandable ? 'expandable' : ''} ${isExpanded ? 'expanded' : ''} ${isSpouse ? 'spouse' : ''}`}
      style={{ width: LAYOUT.NODE_WIDTH, height: LAYOUT.NODE_HEIGHT }}
    >
      <Handle type="target" position={Position.Top} style={{ opacity: 0 }} />

      <div className="node-circle" style={{ width: LAYOUT.CIRCLE_SIZE, height: LAYOUT.CIRCLE_SIZE }}>
        <div className="circle-inner" />
        {isExpandable && !isSpouse && (
          <div className={`expand-btn level-${level}-btn`}>
            {isExpanded ? '−' : '+'}
          </div>
        )}
      </div>

      <div className="node-name">{label}</div>

      <Handle type="source" position={Position.Bottom} style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Right} id="right" style={{ opacity: 0 }} />
      <Handle type="target" position={Position.Left} id="left" style={{ opacity: 0 }} />
    </div>
  );
}

// Invisible connector node for routing edges
function ConnectorNodeComponent() {
  return (
    <div style={{ width: 1, height: 1 }}>
      <Handle type="target" position={Position.Top} style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Bottom} style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Left} id="left" style={{ opacity: 0 }} />
      <Handle type="source" position={Position.Right} id="right" style={{ opacity: 0 }} />
    </div>
  );
}

// Use type assertion to satisfy React Flow's nodeTypes requirement
const nodeTypes = {
  person: PersonNodeComponent,
  connector: ConnectorNodeComponent,
} as const;

// ============================================
// CALCULATE SUBTREE WIDTH
// ============================================
function getSubtreeWidth(node: FamilyMember, expanded: Set<string>): number {
  const isExpanded = expanded.has(node.id);
  const hasSpouse = node.spouse && isExpanded;

  const baseWidth = hasSpouse
    ? LAYOUT.NODE_WIDTH + LAYOUT.SPOUSE_GAP
    : LAYOUT.NODE_WIDTH;

  if (!isExpanded || node.children.length === 0) {
    return baseWidth;
  }

  const childrenWidth = node.children.reduce((sum, child, i) => {
    return sum + getSubtreeWidth(child, expanded) + (i > 0 ? LAYOUT.HORIZONTAL_SPACING : 0);
  }, 0);

  return Math.max(baseWidth, childrenWidth);
}

// ============================================
// MAIN TREE COMPONENT (INNER)
// ============================================
function FamilyTreeInner() {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [edgesVisible, setEdgesVisible] = useState(true);
  const { fitView, setViewport, getViewport } = useReactFlow();
  const nodesInitialized = useNodesInitialized();
  const isFirstRender = useRef(true);
  const viewportBeforeExpand = useRef<{ x: number; y: number; zoom: number } | null>(null);

  // Only fit view on first render
  useEffect(() => {
    if (isFirstRender.current && nodesInitialized) {
      fitView({ padding: 0.3, duration: 0 });
      isFirstRender.current = false;
    }
  }, [fitView, nodesInitialized]);

  // Show edges only after nodes are initialized (prevents flicker)
  useEffect(() => {
    if (!nodesInitialized) {
      setEdgesVisible(false);
    } else {
      // Small delay to ensure positions are finalized
      const timer = setTimeout(() => setEdgesVisible(true), 20);
      return () => clearTimeout(timer);
    }
  }, [nodesInitialized, expanded]);

  const onNodeClick = useCallback(
    (_event: React.MouseEvent, node: Node) => {
      const data = node.data as PersonNodeData;
      if (!data.personId) return; // It's a connector node

      const { isExpandable, isSpouse, personId } = data;

      if (isExpandable && !isSpouse && personId) {
        viewportBeforeExpand.current = getViewport();

        // Hide edges before state change
        setEdgesVisible(false);

        setExpanded(prev => {
          const next = new Set(prev);
          if (next.has(personId)) {
            next.delete(personId);
          } else {
            next.add(personId);
          }
          return next;
        });

        // Restore viewport after layout settles
        setTimeout(() => {
          if (viewportBeforeExpand.current) {
            setViewport(viewportBeforeExpand.current, { duration: 0 });
          }
        }, 30);
      }
    },
    [getViewport, setViewport]
  );

  const { nodes, edges } = useMemo(() => {
    const nodes: Node[] = [];
    const edges: Edge[] = [];

    function processNode(
      member: FamilyMember,
      x: number,
      y: number,
      level: number,
      parentConnectorId?: string
    ) {
      const isExpanded = expanded.has(member.id);
      const hasSpouse = member.spouse && isExpanded;
      const hasChildren = member.children.length > 0;
      const isExpandable = hasChildren || !!member.spouse;

      const personCenterX = x + LAYOUT.NODE_WIDTH / 2;

      // Main person node
      nodes.push({
        id: member.id,
        type: 'person',
        position: { x, y },
        data: {
          label: member.name,
          isExpandable,
          isExpanded,
          isSpouse: false,
          level,
          personId: member.id,
        } satisfies PersonNodeData,
      });

      // Spouse node
      if (hasSpouse) {
        const spouseX = x + LAYOUT.SPOUSE_GAP;
        const spouseId = `${member.id}-spouse`;

        nodes.push({
          id: spouseId,
          type: 'person',
          position: { x: spouseX, y },
          data: {
            label: member.spouse,
            isExpandable: false,
            isExpanded: false,
            isSpouse: true,
            level,
            personId: spouseId,
          } satisfies PersonNodeData,
        });

        // Marriage line
        edges.push({
          id: `marriage-${member.id}`,
          source: member.id,
          target: spouseId,
          sourceHandle: 'right',
          targetHandle: 'left',
          type: 'straight',
          style: { stroke: LEVEL_COLORS[level], strokeWidth: 2 },
        });
      }

      // Edge from parent connector
      if (parentConnectorId) {
        edges.push({
          id: `child-${parentConnectorId}-${member.id}`,
          source: parentConnectorId,
          target: member.id,
          type: 'straight',
          style: { stroke: LEVEL_COLORS[level - 1] || LEVEL_COLORS[1], strokeWidth: 2 },
        });
      }

      // Process children
      if (isExpanded && member.children.length > 0) {
        const coupleCenterX = hasSpouse
          ? x + LAYOUT.SPOUSE_GAP / 2 + LAYOUT.NODE_WIDTH / 2
          : personCenterX;

        const mainConnectorY = y + LAYOUT.NODE_HEIGHT + LAYOUT.CONNECTOR_DROP;
        const mainConnectorId = `connector-${member.id}`;

        nodes.push({
          id: mainConnectorId,
          type: 'connector',
          position: { x: coupleCenterX, y: mainConnectorY },
          data: {},
        });

        edges.push({
          id: `vertical-${member.id}`,
          source: member.id,
          target: mainConnectorId,
          type: 'straight',
          style: { stroke: LEVEL_COLORS[level], strokeWidth: 2 },
        });

        const childrenWidths = member.children.map(child =>
          getSubtreeWidth(child, expanded)
        );
        const totalChildrenWidth = childrenWidths.reduce((sum, w, i) =>
          sum + w + (i > 0 ? LAYOUT.HORIZONTAL_SPACING : 0), 0
        );

        let childX = coupleCenterX - totalChildrenWidth / 2;
        const childY = y + LAYOUT.VERTICAL_SPACING;
        const horizontalBarY = mainConnectorY + LAYOUT.HORIZONTAL_BAR_DROP / 2;

        if (member.children.length > 1) {
          const firstChildCenterX = childX + childrenWidths[0] / 2;
          const lastChildCenterX = childX + totalChildrenWidth - childrenWidths[childrenWidths.length - 1] / 2;

          const barConnectorId = `bar-${member.id}`;
          nodes.push({
            id: barConnectorId,
            type: 'connector',
            position: { x: coupleCenterX, y: horizontalBarY },
            data: {},
          });

          edges.push({
            id: `drop-${member.id}`,
            source: mainConnectorId,
            target: barConnectorId,
            type: 'straight',
            style: { stroke: LEVEL_COLORS[level], strokeWidth: 2 },
          });

          const leftBarId = `bar-left-${member.id}`;
          nodes.push({
            id: leftBarId,
            type: 'connector',
            position: { x: firstChildCenterX, y: horizontalBarY },
            data: {},
          });

          const rightBarId = `bar-right-${member.id}`;
          nodes.push({
            id: rightBarId,
            type: 'connector',
            position: { x: lastChildCenterX, y: horizontalBarY },
            data: {},
          });

          edges.push({
            id: `hbar-${member.id}`,
            source: leftBarId,
            target: rightBarId,
            sourceHandle: 'right',
            targetHandle: 'left',
            type: 'straight',
            style: { stroke: LEVEL_COLORS[level], strokeWidth: 2 },
          });

          member.children.forEach((child, i) => {
            const childWidth = childrenWidths[i];
            const childCenterX = childX + childWidth / 2;

            const childConnectorId = `child-connector-${child.id}`;
            nodes.push({
              id: childConnectorId,
              type: 'connector',
              position: { x: childCenterX, y: horizontalBarY },
              data: {},
            });

            const childNodeX = childCenterX - LAYOUT.NODE_WIDTH / 2;
            processNode(child, childNodeX, childY, level + 1, childConnectorId);

            childX += childWidth + LAYOUT.HORIZONTAL_SPACING;
          });

        } else {
          const child = member.children[0];
          const childNodeX = coupleCenterX - LAYOUT.NODE_WIDTH / 2;
          processNode(child, childNodeX, childY, level + 1, mainConnectorId);
        }
      }
    }

    processNode(familyData as FamilyMember, 0, 0, 1);

    return { nodes, edges };
  }, [expanded]);

  // Only show edges when visible flag is true
  const visibleEdges = edgesVisible ? edges : [];

  return (
    <ReactFlow
      nodes={nodes}
      edges={visibleEdges}
      nodeTypes={nodeTypes}
      onNodeClick={onNodeClick}
      fitView={false}
      defaultViewport={{ x: 400, y: 50, zoom: 0.8 }}
      minZoom={0.1}
      maxZoom={2}
      nodesDraggable={false}
      nodesConnectable={false}
      panOnDrag
      zoomOnScroll
      zoomOnPinch
      panOnScroll
      selectNodesOnDrag={false}
      proOptions={{ hideAttribution: true }}
    />
  );
}

// ============================================
// WRAPPER WITH PROVIDER
// ============================================
export default function FamilyTreeFlow() {
  return (
    <div className="family-tree-wrapper">
      <h1 className="tree-title">HINA Parivar</h1>
      <div className="tree-container">
        <ReactFlowProvider>
          <FamilyTreeInner />
        </ReactFlowProvider>
      </div>
    </div>
  );
}
