import FamilyTreeFlow from './components/FamilyTreeFlow'
import './App.css'

function App() {
  return <FamilyTreeFlow />
}

export default App
