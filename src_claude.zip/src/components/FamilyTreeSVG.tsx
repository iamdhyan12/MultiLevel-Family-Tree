import React, { useState, useCallback, useRef, useEffect, forwardRef } from "react";
import "./FamilyTreeSVG.css";

// Import types
import type { Person, ExpandableData } from "../data/familyTreeData";

// Import data
import {
  level1Data,
  level2Data,
  level3Data,
  expandableNodesData,
  allExpandableData,
} from "../data/familyTreeData";

// ============================================
// PERSON NODE COMPONENT
// ============================================
interface PersonNodeProps {
  person: Person;
  isExpandable?: boolean;
  isExpanded?: boolean;
  isSpouse?: boolean;
  nodeType?: 'son' | 'daughter';
  level?: number;
  onClick?: () => void;
}

const PersonNode = forwardRef<HTMLDivElement, PersonNodeProps>(
  ({ person, isExpandable = false, isExpanded = false, isSpouse = false, nodeType, level = 1, onClick }, ref) => {
    return (
      <div
        ref={ref}
        className={`person-node ${isExpandable ? "expandable" : ""} ${isExpanded ? "expanded" : ""} ${isSpouse ? "spouse-node" : ""} ${nodeType || ""} level-${level}-node`}
        onClick={isExpandable && !isSpouse ? onClick : undefined}
        data-node-id={person.id}
      >
        <div className="node-circle">
          <div className="circle-placeholder" />
          {isExpandable && !isSpouse && (
            <div className="expand-btn">{isExpanded ? "−" : "+"}</div>
          )}
        </div>
        <div className="node-label">
          <span className="node-name">{person.name}</span>
          <span className="node-lifespan">{person.lifespan}</span>
        </div>
      </div>
    );
  }
);

PersonNode.displayName = "PersonNode";

// ============================================
// RECURSIVE EXPANDABLE NODE COMPONENT
// Handles all levels uniformly
// ============================================
interface ExpandableNodeProps {
  person: Person;
  spouse?: Person | null;
  children?: Person[];
  level: number;
  expandedNodes: Set<string>;
  onToggle: (id: string) => void;
  nodeRefs: React.MutableRefObject<Map<string, HTMLDivElement | null>>;
  nodeType?: 'son' | 'daughter';
}

const ExpandableNode: React.FC<ExpandableNodeProps> = ({
  person,
  spouse,
  children = [],
  level,
  expandedNodes,
  onToggle,
  nodeRefs,
  nodeType,
}) => {
  const isExpanded = expandedNodes.has(person.id);

  // For deeper levels, check allExpandableData
  const expandData = allExpandableData[person.id];
  const actualSpouse = spouse !== undefined ? spouse : expandData?.spouse;
  const actualChildren = children.length > 0 ? children : (expandData?.children || []);
  const actualNodeType = nodeType || expandData?.type;

  const isExpandable = actualSpouse !== null || actualChildren.length > 0;

  const setNodeRef = (id: string) => (el: HTMLDivElement | null) => {
    nodeRefs.current.set(id, el);
  };

  return (
    <div className={`expandable-slot level-${level}-slot`}>
      <div className={`expandable-couple-row ${isExpanded ? "expanded" : ""}`}>
        <PersonNode
          ref={setNodeRef(person.id)}
          person={person}
          isExpandable={isExpandable}
          isExpanded={isExpanded}
          nodeType={actualNodeType}
          level={level}
          onClick={() => onToggle(person.id)}
        />
        {isExpanded && actualSpouse && (
          <PersonNode
            ref={setNodeRef(`${person.id}-spouse`)}
            person={actualSpouse}
            isSpouse={true}
            level={level}
          />
        )}
      </div>

      {/* Recursively render children */}
      {isExpanded && actualChildren.length > 0 && (
        <div className="expandable-children-row">
          {actualChildren.map((child) => (
            <ExpandableNode
              key={child.id}
              person={child}
              level={level + 1}
              expandedNodes={expandedNodes}
              onToggle={onToggle}
              nodeRefs={nodeRefs}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// ============================================
// MAIN FAMILY TREE COMPONENT
// ============================================
const FamilyTreeSVG: React.FC = () => {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const treeRef = useRef<HTMLDivElement>(null);
  const nodeRefs = useRef<Map<string, HTMLDivElement | null>>(new Map());
  const [svgLines, setSvgLines] = useState<{ x1: number; y1: number; x2: number; y2: number; color: string }[]>([]);

  // Level 1 is expandable - children are Level 2 people (primary from each couple)
  const isLevel1Expanded = expandedNodes.has(level1Data.primary.id);

  const handleToggle = useCallback((nodeId: string) => {
    setExpandedNodes((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(nodeId)) {
        newSet.delete(nodeId);
      } else {
        newSet.add(nodeId);
      }
      return newSet;
    });
  }, []);

  const setNodeRef = (id: string) => (el: HTMLDivElement | null) => {
    nodeRefs.current.set(id, el);
  };

  // Color scheme for different levels
  const getLevelColor = (level: number): string => {
    const colors: Record<number, string> = {
      1: "#343a40",
      2: "#343a40",
      3: "#e74c3c", // Red
      4: "#9b59b6", // Purple
      5: "#2980b9", // Blue
      6: "#27ae60", // Green
      7: "#f39c12", // Orange
    };
    return colors[level] || "#343a40";
  };

  // ============================================
  // LINE CALCULATION
  // ============================================
  useEffect(() => {
    const calculateLines = () => {
      if (!treeRef.current) return;

      const newLines: { x1: number; y1: number; x2: number; y2: number; color: string }[] = [];
      const containerRect = treeRef.current.getBoundingClientRect();

      const getNodePos = (nodeId: string) => {
        const nodeEl = nodeRefs.current.get(nodeId);
        if (!nodeEl) return null;
        const rect = nodeEl.getBoundingClientRect();
        const circleEl = nodeEl.querySelector(".node-circle");
        const circleRect = circleEl?.getBoundingClientRect() || rect;
        return {
          centerX: circleRect.left + circleRect.width / 2 - containerRect.left,
          centerY: circleRect.top + circleRect.height / 2 - containerRect.top,
          top: circleRect.top - containerRect.top,
          bottom: circleRect.bottom - containerRect.top,
        };
      };

      const drawMarriageLine = (person1Id: string, person2Id: string, color: string = "#343a40") => {
        const pos1 = getNodePos(person1Id);
        const pos2 = getNodePos(person2Id);
        if (!pos1 || !pos2) return;

        newLines.push({
          x1: pos1.centerX,
          y1: pos1.centerY,
          x2: pos2.centerX,
          y2: pos2.centerY,
          color,
        });
      };

      // Draw family lines from a parent couple to children
      const drawFamilyLines = (personId: string, spouseId: string | null, childrenIds: string[], level: number) => {
        const personPos = getNodePos(personId);
        if (!personPos) return;

        const color = getLevelColor(level);

        // Marriage line
        if (spouseId) {
          const spousePos = getNodePos(spouseId);
          if (spousePos) {
            drawMarriageLine(personId, spouseId, color);

            // Children lines
            if (childrenIds.length > 0) {
              const childPositions = childrenIds
                .map(id => {
                  const pos = getNodePos(id);
                  return pos ? { id, ...pos } : null;
                })
                .filter(Boolean) as { id: string; centerX: number; centerY: number; top: number; bottom: number }[];

              if (childPositions.length > 0) {
                const marriageCenterX = (personPos.centerX + spousePos.centerX) / 2;
                const marriageY = personPos.centerY;

                const firstChild = childPositions[0];
                const lastChild = childPositions[childPositions.length - 1];
                const childrenHorizontalY = marriageY + (firstChild.top - marriageY) / 2 + 20;

                // Vertical line from marriage to horizontal bar
                newLines.push({
                  x1: marriageCenterX,
                  y1: marriageY,
                  x2: marriageCenterX,
                  y2: childrenHorizontalY,
                  color,
                });

                // Horizontal line
                const leftX = Math.min(marriageCenterX, firstChild.centerX, lastChild.centerX);
                const rightX = Math.max(marriageCenterX, firstChild.centerX, lastChild.centerX);

                if (leftX !== rightX) {
                  newLines.push({
                    x1: leftX,
                    y1: childrenHorizontalY,
                    x2: rightX,
                    y2: childrenHorizontalY,
                    color,
                  });
                }

                // Vertical lines to each child
                childPositions.forEach((childPos) => {
                  newLines.push({
                    x1: childPos.centerX,
                    y1: childrenHorizontalY,
                    x2: childPos.centerX,
                    y2: childPos.top,
                    color,
                  });
                });
              }
            }
          }
        }
      };

      // Process expanded nodes recursively
      const processExpandedNode = (personId: string, level: number) => {
        if (!expandedNodes.has(personId)) return;

        // Special case for level 1 (root)
        if (personId === level1Data.primary.id) {
          const spouseId = level1Data.secondary.id;
          const childrenIds = level2Data.map(couple => couple.primary.id);
          drawFamilyLines(personId, spouseId, childrenIds, 1);

          // Process level 2 children
          childrenIds.forEach(childId => processExpandedNode(childId, 2));
          return;
        }

        // Check if this is a level 2 person (from level2Data)
        const level2Couple = level2Data.find(c => c.primary.id === personId);
        if (level2Couple) {
          const spouseId = `${personId}-spouse`;
          const childrenIds = level2Couple.childrenIds;
          drawFamilyLines(personId, spouseId, childrenIds, 2);

          // Process level 3 children
          childrenIds.forEach(childId => processExpandedNode(childId, 3));
          return;
        }

        // Check in allExpandableData for deeper levels
        const expandData = allExpandableData[personId];
        if (expandData) {
          const spouseId = expandData.spouse ? `${personId}-spouse` : null;
          const childrenIds = expandData.children.map(c => c.id);
          drawFamilyLines(personId, spouseId, childrenIds, level);

          // Process children
          childrenIds.forEach(childId => processExpandedNode(childId, level + 1));
        }
      };

      // Start processing from root
      processExpandedNode(level1Data.primary.id, 1);

      setSvgLines(newLines);
    };

    const timer1 = setTimeout(calculateLines, 50);
    const timer2 = setTimeout(calculateLines, 350);
    const timer3 = setTimeout(calculateLines, 600);

    window.addEventListener("resize", calculateLines);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      window.removeEventListener("resize", calculateLines);
    };
  }, [expandedNodes]);

  // Build level 2 data with their spouses and children for the recursive component
  const getLevel2ExpandData = (coupleData: typeof level2Data[0]) => {
    return {
      spouse: coupleData.secondary,
      children: coupleData.childrenIds.map(id => level3Data[id]),
    };
  };

  return (
    <div className="family-tree-wrapper">
      <h1 className="tree-title">HINA Parivar</h1>

      <div className="tree-scroll-container">
        <div className="family-tree-container" ref={treeRef}>
          {/* SVG Layer for all lines */}
          <svg className="tree-lines-svg">
            {svgLines.map((line, i) => (
              <line
                key={i}
                x1={line.x1}
                y1={line.y1}
                x2={line.x2}
                y2={line.y2}
                stroke={line.color}
                strokeWidth="2"
              />
            ))}
          </svg>

          {/* Level 1: Root - Expandable */}
          <div className="expandable-slot level-1-slot root-slot">
            <div className={`expandable-couple-row ${isLevel1Expanded ? "expanded" : ""}`}>
              <PersonNode
                ref={setNodeRef(level1Data.primary.id)}
                person={level1Data.primary}
                isExpandable={true}
                isExpanded={isLevel1Expanded}
                level={1}
                onClick={() => handleToggle(level1Data.primary.id)}
              />
              {isLevel1Expanded && (
                <PersonNode
                  ref={setNodeRef(level1Data.secondary.id)}
                  person={level1Data.secondary}
                  isSpouse={true}
                  level={1}
                />
              )}
            </div>

            {/* Level 2: Children of root */}
            {isLevel1Expanded && (
              <div className="expandable-children-row">
                {level2Data.map((couple) => {
                  const expandData = getLevel2ExpandData(couple);
                  return (
                    <ExpandableNode
                      key={couple.primary.id}
                      person={couple.primary}
                      spouse={expandData.spouse}
                      children={expandData.children}
                      level={2}
                      expandedNodes={expandedNodes}
                      onToggle={handleToggle}
                      nodeRefs={nodeRefs}
                    />
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FamilyTreeSVG;
