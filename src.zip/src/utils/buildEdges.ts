export function buildEdges(elkNode: any, edges: any[] = []) {
    if (elkNode.children && elkNode.children.length > 0) {
        elkNode.children.forEach((child: any) => {
            edges.push({
                from: { x: elkNode.x + elkNode.width, y: elkNode.y + elkNode.height / 2 },
                to: { x: child.x, y: child.y + child.height / 2 }
            });
            buildEdges(child, edges);
        });
    }
    return edges;
}
