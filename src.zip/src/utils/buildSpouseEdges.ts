export function buildSpouseEdges(nodes: any[]) {
    return nodes
        .filter(n => n.data.attributes.spouse)
        .map(n => ({
            from: { x: n.x + 100, y: n.y + 40 },
            to: { x: n.x + 200, y: n.y + 40 }
        }));
}
