export function flattenTree(elkNode: any, nodes: any[] = []) {
    if (elkNode.children) {
        elkNode.children.forEach((child: any) => {
            nodes.push({
                id: child.id,
                x: child.x,
                y: child.y,
                data: child.data,   // contains name, spouse, children
            });
            flattenTree(child, nodes);
        });
    }
    return nodes;
}
