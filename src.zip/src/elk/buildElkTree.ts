import type { ElkNode, ElkExtendedEdge } from "elkjs";

export function buildElkTree(root: any): ElkNode {
    function build(node: any): ElkNode {
        const elkNode: ElkNode = {
            id: node.attributes.id,
            width: 200,
            height: 120,
            children: [],
        };

        // add children (ELK will layout vertically)
        if (node.children && node.children.length > 0) {
            elkNode.children = node.children.map((child: any) => build(child));
        }

        return elkNode;
    }

    return {
        id: "root",
        children: [build(root)],
        layoutOptions: {
            "elk.algorithm": "layered",
            "elk.direction": "RIGHT", // horizontal tree
            "elk.spacing.nodeNode": "60",
            "elk.layered.spacing.edgeEdgeBetweenLayers": "40",
            "elk.edgeRouting": "ORTHOGONAL",
            "elk.layered.nodePlacement.strategy": "NETWORK_SIMPLEX",
        }
    };
}
