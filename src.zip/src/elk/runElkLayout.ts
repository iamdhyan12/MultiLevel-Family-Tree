import ELK from "elkjs";

const elk = new ELK();

export async function runElkLayout(graph: any) {
    const layout = await elk.layout(graph);
    return layout;
}