// src/components/FamilyTree.tsx

import React, { useEffect, useState } from "react";
import family from "../data/family.json";
import ELK from "elkjs/lib/elk.bundled.js";

// -----------------------------
// Types
// -----------------------------
export interface FamilyNode {
  name: string;
  attributes: {
    id: string;
    spouse: string;
  };
  children?: FamilyNode[];
}

export interface ElkNodeWithData {
  id: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  children?: ElkNodeWithData[];
  data?: FamilyNode;
  layoutOptions?: Record<string, string>;
}

interface PositionedNode {
  id: string;
  x: number;
  y: number;
  data: FamilyNode;
}

interface Edge {
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
}

// -----------------------------
// Layout Constants
// -----------------------------
const NODE_RADIUS = 35;
const SPOUSE_OFFSET = 120;

// -----------------------------
// Helpers
// -----------------------------

function indexFamilyTree(root: FamilyNode): Record<string, FamilyNode> {
  const map: Record<string, FamilyNode> = {};

  function dfs(node: FamilyNode) {
    map[node.attributes.id] = node;
    node.children?.forEach(dfs);
  }

  dfs(root);
  return map;
}

/**
 * Create a new tree where collapsed nodes have no children.
 */
function buildVisibleTree(
  node: FamilyNode,
  collapsed: Set<string>,
): FamilyNode {
  const isCollapsed = collapsed.has(node.attributes.id);
  return {
    ...node,
    children: isCollapsed
      ? []
      : node.children?.map((c) => buildVisibleTree(c, collapsed)),
  };
}

/**
 * Converts the visible family tree to an ELK.js input graph.
 */
function buildElkGraph(root: FamilyNode): ElkNodeWithData {
  function buildNode(n: FamilyNode): ElkNodeWithData {
    return {
      id: n.attributes.id,
      width: 220,
      height: 120,
      data: n,
      children: n.children?.map(buildNode) ?? [],
    };
  }

  return {
    id: "root",
    children: [buildNode(root)],
    layoutOptions: {
      "elk.algorithm": "layered",
      "elk.direction": "RIGHT",
      "elk.spacing.nodeNode": "70",
      "elk.edgeRouting": "ORTHOGONAL",
      "elk.layered.spacing.edgeEdgeBetweenLayers": "40",
      "elk.layered.nodePlacement.strategy": "NETWORK_SIMPLEX",
    },
  };
}

/**
 * Run ELK layout.
 */
async function runLayout(graph: ElkNodeWithData): Promise<ElkNodeWithData> {
  const elk = new ELK();
  return (await elk.layout(graph as any)) as ElkNodeWithData;
}

/**
 * Flatten ELK result into positioned nodes.
 */
function flattenNodes(
  elkNode: ElkNodeWithData,
  acc: PositionedNode[],
) {
  const x = (elkNode.x ?? 0) + (elkNode.width ?? 0) / 2;
  const y = (elkNode.y ?? 0) + (elkNode.height ?? 0) / 2;

  if (elkNode.data) {
    acc.push({
      id: elkNode.id,
      x,
      y,
      data: elkNode.data,
    });
  }

  elkNode.children?.forEach((c) => flattenNodes(c, acc));
}

/**
 * Build parent → child edges.
 */
function buildTreeEdges(
  elkNode: ElkNodeWithData,
  acc: Edge[],
) {
  const px = (elkNode.x ?? 0) + (elkNode.width ?? 0) / 2;
  const py = (elkNode.y ?? 0) + (elkNode.height ?? 0) / 2;

  elkNode.children?.forEach((child) => {
    const cx = (child.x ?? 0) + (child.width ?? 0) / 2;
    const cy = (child.y ?? 0) + (child.height ?? 0) / 2;

    acc.push({ fromX: px, fromY: py, toX: cx, toY: cy });

    buildTreeEdges(child, acc);
  });
}

/**
 * Build spouse side connectors.
 */
function buildSpouseEdges(nodes: PositionedNode[]): Edge[] {
  return nodes
    .filter((n) => n.data.attributes.spouse)
    .map((n) => ({
      fromX: n.x,
      fromY: n.y,
      toX: n.x + SPOUSE_OFFSET,
      toY: n.y,
    }));
}

// -----------------------------
// Main Component
// -----------------------------

const ROOT_FAMILY: FamilyNode = (family as FamilyNode[])[0];
const FAMILY_INDEX = indexFamilyTree(ROOT_FAMILY);

export default function FamilyTree() {
  const [collapsed, setCollapsed] = useState<Set<string>>(
    () => new Set(),
  );
  const [nodes, setNodes] = useState<PositionedNode[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);

  useEffect(() => {
    async function doLayout() {
      const visible = buildVisibleTree(ROOT_FAMILY, collapsed);
      const elkGraph = buildElkGraph(visible);
      const result = await runLayout(elkGraph);

      const top = result.children?.[0];
      if (!top) return;

      const flat: PositionedNode[] = [];
      flattenNodes(top, flat);

      const treeEdges: Edge[] = [];
      buildTreeEdges(top, treeEdges);

      const spouseEdges = buildSpouseEdges(flat);

      setNodes(flat);
      setEdges([...treeEdges, ...spouseEdges]);
    }

    void doLayout();
  }, [collapsed]);

  // dynamic viewbox
  let viewBox = "0 0 1200 800";
  if (nodes.length > 0) {
    let minX = Infinity,
      minY = Infinity,
      maxX = -Infinity,
      maxY = -Infinity;

    nodes.forEach((n) => {
      minX = Math.min(minX, n.x);
      maxX = Math.max(maxX, n.x);
      minY = Math.min(minY, n.y);
      maxY = Math.max(maxY, n.y);
    });

    const margin = 120;
    const width = maxX - minX || 800;
    const height = maxY - minY || 600;

    viewBox = `${minX - margin} ${minY - margin} ${width + margin * 2
      } ${height + margin * 2}`;
  }

  const handleToggle = (id: string) => {
    const node = FAMILY_INDEX[id];
    if (!node.children || node.children.length === 0) return;

    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <svg
      width="100%"
      height="100vh"
      viewBox={viewBox}
      style={{ background: "#fafafa" }}
    >
      {/* connectors */}
      <g stroke="#777" strokeWidth={2}>
        {edges.map((e, i) => (
          <line
            key={i}
            x1={e.fromX}
            y1={e.fromY}
            x2={e.toX}
            y2={e.toY}
          />
        ))}
      </g>

      {/* nodes */}
      {nodes.map((n) => {
        const fullNode = FAMILY_INDEX[n.id];
        const hasChildren =
          fullNode.children && fullNode.children.length > 0;
        const isCollapsed = collapsed.has(n.id);

        return (
          <g
            key={n.id}
            transform={`translate(${n.x}, ${n.y})`}
            style={{ cursor: hasChildren ? "pointer" : "default" }}
          >
            {/* person */}
            <circle
              r={NODE_RADIUS}
              fill="white"
              stroke="#333"
              strokeWidth={3}
              onClick={() => handleToggle(n.id)}
            />
            <text
              textAnchor="middle"
              y={NODE_RADIUS + 18}
              fontSize={14}
            >
              {n.data.name}
            </text>

            {/* spouse */}
            {n.data.attributes.spouse && (
              <>
                <circle
                  cx={SPOUSE_OFFSET}
                  r={NODE_RADIUS}
                  fill="white"
                  stroke="#666"
                  strokeWidth={2}
                />
                <text
                  x={SPOUSE_OFFSET}
                  y={NODE_RADIUS + 18}
                  textAnchor="middle"
                  fontSize={14}
                >
                  {n.data.attributes.spouse}
                </text>
              </>
            )}

            {/* expand/collapse */}
            {hasChildren && (
              <g
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggle(n.id);
                }}
              >
                <rect
                  x={-15}
                  y={-NODE_RADIUS - 33}
                  width={30}
                  height={26}
                  rx={6}
                  fill="#eee"
                  stroke="#333"
                />
                <text
                  x={0}
                  y={-NODE_RADIUS - 15}
                  textAnchor="middle"
                  fontSize={18}
                  fontWeight="bold"
                >
                  {isCollapsed ? "+" : "–"}
                </text>
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
}
