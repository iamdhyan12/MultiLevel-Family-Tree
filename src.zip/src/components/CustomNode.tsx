import type { TreeNodeDatum } from "react-d3-tree";
import React from "react";

export default function CustomNode({ nodeDatum, toggleNode }: {
    nodeDatum: TreeNodeDatum;
    toggleNode: () => void;
}) {
    const spouse = nodeDatum.attributes?.spouse ?? "";
    const collapsed = nodeDatum.__rd3t?.collapsed;

    const circleR = 40;

    return (
        <g>
            <circle
                r={circleR}
                fill="#ffffff"
                stroke="#333"
                strokeWidth={3}
            />

            <text
                x={0}
                y={circleR + 18}
                textAnchor="middle"
                fontSize={14}
            >
                {nodeDatum.name}
            </text>

            {spouse && (
                <>
                    <circle
                        cx={circleR * 2}
                        r={circleR}
                        fill="#ffffff"
                        stroke="#555"
                        strokeWidth={2}
                    />
                    <text
                        x={circleR * 2}
                        y={circleR + 18}
                        textAnchor="middle"
                        fontSize={14}
                    >
                        {spouse}
                    </text>
                </>
            )}

            {nodeDatum.children && (
                <g onClick={toggleNode} style={{ cursor: "pointer" }}>
                    <rect
                        x={-15}
                        y={-circleR - 35}
                        width={30}
                        height={30}
                        rx={7}
                        fill="#eee"
                        stroke="#333"
                    />
                    <text
                        x={0}
                        y={-circleR - 15}
                        textAnchor="middle"
                        fontSize={20}
                        fontWeight="bold"
                    >
                        {collapsed ? "+" : "–"}
                    </text>
                </g>
            )}
        </g>
    );
}
