export default function Connectors({ edges }: any) {
    return (
        <g>
            {edges.map((e: any, i: number) => (
                <path
                    key={i}
                    d={`M${e.from.x},${e.from.y} L${e.to.x},${e.to.y}`}
                    stroke="#555"
                    fill="none"
                />
            ))}
        </g>
    );
}
