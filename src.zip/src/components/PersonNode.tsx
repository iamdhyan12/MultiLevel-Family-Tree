
export default function PersonNode({ x, y, node }: any) {
    const person = node.data;
    const spouse = person.attributes.spouse;

    return (
        <g transform={`translate(${x}, ${y})`}>
            <circle r={40} fill="white" stroke="#333" strokeWidth={3} />
            <text textAnchor="middle" y={60}>{person.name}</text>

            {spouse && (
                <>
                    <circle cx={120} r={40} fill="white" stroke="#555" strokeWidth={2} />
                    <text x={120} y={60} textAnchor="middle">{spouse}</text>
                </>
            )}
        </g>
    );
}
