import './App.css'
import React from "react";
import FamilyTree from "./components/FamilyTree";

function App() {
  // return <FamilyTreeSVG />
  return <FamilyTree />
}

export default App
