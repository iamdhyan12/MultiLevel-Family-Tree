import FamilyTreeSVG from './components/FamilyTreeSVG'
import './App.css'

function App() {
  return <FamilyTreeSVG />
}

export default App
