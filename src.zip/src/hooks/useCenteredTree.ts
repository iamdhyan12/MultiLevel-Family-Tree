import { useRef, useLayoutEffect, useState } from "react";

export default function useCenteredTree(defaultTranslate = { x: 0, y: 0 }) {
    const containerRef = useRef<HTMLDivElement>(null);
    const [translate, setTranslate] = useState(defaultTranslate);

    useLayoutEffect(() => {
        const bounds = containerRef.current?.getBoundingClientRect();
        if (bounds) {
            setTranslate({
                x: bounds.width / 8,
                y: bounds.height / 2,
            });
        }
    }, []);

    return [translate, containerRef] as const;
}
